package Opp1;

import java.util.Arrays;

public class Rekursjon {

    // 2^5
    static int pow(int base, int exponent) {
        if (exponent < 1) {
            return 1;
        } else {
            return base * pow(base, exponent -= 1);
        }


    }

    public static void main(String[] args) {

        System.out.println(sum1(5));
        System.out.println(pow(2, 5));
        System.out.println(toList(new int[]{1, 2, 3, -5}, 4));
        System.out.println(min(new double[]{1, 2, -333, 3},0 ));
        System.out.println(binærsøk(new int []{1,5,5,8,6,7,6},  15));

    }

    static int sum1(int x) {
        if (x > 0) {
            return x + sum1(x -= 1);
        } else {
            return 0;
        }
    } // liste[3] + " "+listing(liste,3) ; -> 4 +liste[2] + listing (liste, 1)

    /*
        static String listing(int[] liste, int size) {
            int størst;
           // String melding = "";
            if (size > 0) {  // 5
                størst = liste[0];// største = 1
                if (liste[size - 1] > liste[0]) {
                    størst = liste[size--];
                }
                return størst +"" ;
                return liste[size - 1] + " " + listing(liste, size -= 1);
            }

    /*

        }*/
    public static String toList(int[] liste, int size) {

        if (size > 0) {
            int s = --size;

            return liste[s] + " " + toList(liste, s--);
        } else return "";
    }/*
    static int minst(int [] liste , int indeks){
        if((liste.length)-1 == indeks){
            //return liste[indeks] ;
            if (liste[indeks]< minst(liste, --indeks)){
                return liste[indeks];
            }
          //  else return
        }
        int val = liste[indeks] ;
        if (liste[indeks] < val) {
            return liste[indeks] ;
        }
        else return minst(liste, ++indeks) ;

    }*/
    public static double min(double[] elements, int index) {

        if (index == elements.length - 1) {
            return elements[index];
        }

        double val = min(elements, index + 1);

        if (elements[index] < val)
            return elements[index];
        else
            return val;
    }
    public static int søk(int [] a, int verdi , int start , int end ){

        int  m =  (start + end ) /2 ; // finner midten
        int midtverdi = a[m]; // finner midtverdien
        if (!Arrays.asList(a).contains(verdi)) return -1 ;
        if (verdi> midtverdi ) return søk(a, verdi, m+1 , a.length -1);
        else if(verdi< midtverdi) return søk(a, verdi, 0 , m-1 ) ;
        else return m ; // funnet
    }
    public static int binærsøk(int [] a, int verdi){
        return søk(a,verdi, 0, a.length-1 ) ;
    }
}







/*
    public static void største (int [] liste, int length, int position  ){
        if (length ==1){
            System.out.println(liste[0]);
            return ;
    }   else
        System.out.println(liste[position]) ;
        største(liste, length--, position++);

}/*
   if(liste[s]>st){
           st =liste[s] ;
           return st +" er den største tallet i arrayet!" ;
           }*/