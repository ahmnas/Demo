package Oppgave3;

public class Svar1 {
}
