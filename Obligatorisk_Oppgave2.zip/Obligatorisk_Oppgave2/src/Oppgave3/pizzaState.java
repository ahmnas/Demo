package Oppgave3;

public interface pizzaState {
    void prev(Pizza pz);

    void next(Pizza pz);

    void printStatus();
}