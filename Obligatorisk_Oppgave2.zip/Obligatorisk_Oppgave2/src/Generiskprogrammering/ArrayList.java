package Generiskprogrammering;

import java.util.AbstractList;

public class ArrayList<E> extends AbstractList<E> {
    private final static int maks_antall = 100;
    private Object[] elements = new Object[maks_antall];
    private int counter = 0;

    public boolean add(E element) {
        if (counter <= maks_antall) {

            elements[counter] = element;
            counter++;
            return true;
        } else return false;
    }

    public E get(int index) throws IndexOutOfBoundsException {
        if (index < 0 || index >= size()) {
            throw new IndexOutOfBoundsException("Index is out of range");
        } else return (E) elements[index];

    }

    public int size() {
        return counter;
    }

    public void printer() {
        for (Object ele : elements) {
            if (ele!= null) System.out.println(ele + " ");
        }
    }

    public static void main(String[] args) {
        ArrayList<Integer> array = new ArrayList<Integer>();
        array.add(659);
        array.add(5646);
        System.out.println(array.get(0));
        array.printer();

    }
}
