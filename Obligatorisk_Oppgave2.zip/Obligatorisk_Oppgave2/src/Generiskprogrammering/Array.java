package Generiskprogrammering;

import java.util.ArrayList;

public class Array {
    public static <T> void printElements(T[] list) {
        for (T elements : list) {
            System.out.printf("%s ", elements);
        }
        System.out.println();
    }

    public static <T> void reverse(T[] list) {
        System.out.println("Før reversering var arrayet sånn: ");
        printElements(list);
        System.out.println("Etter reversering ble arrayet sånn: ");
        for(int i = list.length-1; i >=0 ; i--){
            System.out.print(list[i]+ " " ) ;
        }
    }

    public static void main(String[] args) {
        Integer[] array  = {5,2,28,50};
        printElements(array);
        reverse(array);
    }
}