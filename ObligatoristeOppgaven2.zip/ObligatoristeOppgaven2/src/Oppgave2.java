import javax.swing.*;

import static javax.swing.JOptionPane.*;
class Tallspill{
    public int nyTall(){
        return (int ) (Math.random()*201);

    }
    public void visMelding(String melding){
        showMessageDialog(null, melding );
    }
    private void forLite(int tall){
        showMessageDialog(null, tall + " er for lite! Prøv igjen!");
    }
    private void forStort(int tall){
        showMessageDialog(null, tall + " er for stor! Prøv igjen!");
    }
    public void avsluttRunde(int antallgjett, int inputTall) {
        showMessageDialog(null,    inputTall+ " er riktig! \n Du gjettet riktig på " +
                antallgjett + " forsøk.");
    }
    public void kjørespill(){
        // Kjører en spillrunde ved å trekke et tall
        int tilfeldigTall = nyTall();
        System.out.println("Tilfeldig tallet er "  + tilfeldigTall );
        int inputTall;
        int antallgjett = 1;
        try{
          inputTall = Integer.parseInt(showInputDialog("Jeg tenker på et tall mellom 0 og 200 \n Prøv å gjette på tallet!"));
           }
        catch(Exception e){
            inputTall = -1;

            showMessageDialog(null, "Du har skrevet inn et ugyldig " +
                    "tall");
        }
         while(inputTall != tilfeldigTall) {
             if (inputTall == -1) {
                 try {
                     inputTall = Integer.parseInt(showInputDialog("Jeg tenker på et tall mellom 0 og 200 \n Prøv å gjette på tallet!"));
                 } catch (Exception e) {
                     inputTall = -1;
                     showMessageDialog(null, "Du har skrevet inn et ugyldig " +
                             "tall");
                 }
             } else if (inputTall > tilfeldigTall) {
                 forStort(inputTall);
                 antallgjett++;
                 try {
                     inputTall = Integer.parseInt(showInputDialog("Jeg tenker på et tall mellom 0 og 200 \n" +
                             " Prøv å gjette på tallet!"));
                 } catch (Exception e) {
                     inputTall = -1;
                     showMessageDialog(null, "Du har skrevet inn et ugyldig " +
                             "tall");

                 }

             } else if (inputTall < tilfeldigTall) {
                 forLite(inputTall);
                 antallgjett++;
                 try {
                     inputTall = Integer.parseInt(showInputDialog("Jeg tenker på et tall mellom 0 og 200 \n" +
                             " Prøv å gjette på tallet!"));
                 } catch (Exception e) {
                     inputTall = -1;
                     showMessageDialog(null, "Du har skrevet inn et ugyldig " +
                             "tall");


                 }
             }
             if (inputTall == tilfeldigTall) {
                 avsluttRunde(antallgjett,inputTall);

             }
         }

    }
}


public class Oppgave2 {
    public static void main (String [] args){
        Tallspill newGame   = new Tallspill();
        newGame.kjørespill();
    }

}
