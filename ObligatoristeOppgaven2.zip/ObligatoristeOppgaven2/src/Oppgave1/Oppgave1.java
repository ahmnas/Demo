package Oppgave1;
/*  Oppgave 1
Lag et program som beregner og skriver ut summen av alle tall mellom to grenser som brukeren skriver inn.
Programmet skal starte med å lese inn nedre og øvre grense for summen.
Dersom innlest øvre grense er mindre enn eller lik nedre grense, skal programmet skrive ut en melding til brukeren om
dette og foreta ny innlesing. Når godkjente grenser er lest inn, skal programmet beregne nevnte sum og summen skal så
 skrive den ut som en sum. Hvis f. eks. nedre grense er 2 og øvre grense er 8 skal det skrives ut følgende tekst:
  "2 + 3 + 4 + 5 + 6 + 7 + 8 = 35".
Test ut programmet med nedre grense lik 1 og øvre grense lik 100. Legg inn et linjeskift for hvert 10. tall i summen.*/


import javax.swing.*;

public class Oppgave1 {
    public static void main(String [] args){

        int min = Integer.parseInt(  JOptionPane.showInputDialog("Skriv inn en nedre grense "));
        int max = Integer.parseInt (JOptionPane.showInputDialog("Skriv inn et øvre grense "));

// tall2 må være større enn tall1 DVS. at øvre grense > mindre grense

        int sum = 0;
        int teller = 0;

        if(max > min  ){

        for (int i = min ;  i <= max ; i++ ){
            sum += i;
            teller++;
            if (teller == 10 ){
                System.out.println();
                teller = 0;
            }
            if (i < max ) System.out.print(i + " + ");
            else System.out.print(i + " = ");
        }
        System.out.print(  sum + " ");
    }

            else {

            int nyMax = Integer.parseInt(  JOptionPane.showInputDialog("Innlest øvre grense er mindre enn eller lik nedre grense," +
                    "Skriv inn en ny øvre grense  "));
            int nyMin = Integer.parseInt(  JOptionPane.showInputDialog("Skriv inn en nedre grense "));
            for (int i = nyMin ;  i <= nyMax ; i++ ){
                sum += i;
                teller++;
                if (teller == 10 ){
                    System.out.println();
                    teller = 0;
                }
                if (i < nyMax ) System.out.print( i + " + ");
                else System.out.print(i + " = ");
            }
            System.out.print(  sum + " ");
        }

}
/*
     for (tall1 = 0 ; tall1< tall2 ; differanse ++ ){

         if (tall1 <= tall2 ) {
             System.out.println("Øvre grensen  er mindre enn den nedre grensen du skrevet");
             String nyInput = JOptionPane.showInputDialog("Vennglist skriv inn en ny øvre grense");
             int newTall1 = Integer.parseInt(nyInput );
             int nyDifferanse = newTall1 - tall2;
             System.out.print(nyDifferanse + " ");

         }
         else {
             System.out.print( differanse + " ");
         }
     }

     if(tall1 <= tall2 ){
         System.out.println("Øvre grensen  er mindre enn den nedre grensen du skrevet");
         JOptionPane.showInputDialog("Vennglist skriv inn en ny øvre grense");
     }


    }
    */
}
