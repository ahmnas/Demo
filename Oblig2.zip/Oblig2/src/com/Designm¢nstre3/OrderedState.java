package com.Designmønstre3;

class OrderedState implements pizzaState {
    @Override
    public void prev(Pizza pz) {
        System.out.println("The pizza is in its root state");
    }

    @Override
    public void next(Pizza pz) {
        pz.setState(new DeliveredState());
    }

    @Override
    public void printStatus() {
        System.out.println("Pizza ordered, not delivered to the client");
    }
}
