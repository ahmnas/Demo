package com.Designmønstre3;

class ReceivedState implements pizzaState{

    @Override
    public void prev(Pizza pz) {
        pz.setState(new DeliveredState());
    }

    @Override
    public void next(Pizza pz) {
        System.out.println("The pizza is already received by the client");
    }

    @Override
    public void printStatus() {
        System.out.println("The pizza was received by the client ");
    }
}
