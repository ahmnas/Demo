package com.Designmønstre3;

class DeliveredState implements pizzaState {

    @Override
    public void prev(Pizza pz) {
        pz.setState(new OrderedState());
    }

    @Override
    public void next(Pizza pz) {
        pz.setState(new ReceivedState());
    }

    @Override
    public void printStatus() {
        System.out.println("Pizza delivered to the post office, not received yet");
    }
}
