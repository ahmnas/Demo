package com.Designmønstre3;

public interface pizzaState {
    void prev(Pizza pz);

    void next(Pizza pz);

    void printStatus();
}