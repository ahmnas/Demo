package com.Designmønstre3;

public class Svar1 {
}
