package com.Designmønstre3;

public class Demo {
    public static void main(String[] args) {
        Pizza enPizza = new Pizza();
        enPizza.printStatus();

        enPizza.nextState();
        enPizza.printStatus();

        enPizza.nextState();
        enPizza.printStatus();


    }
}
