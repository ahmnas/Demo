package com.Generisk2;

public class Main{


    public static <A> void printArray (A[] array){
        for (int i = 0; i < array.length; i++){
            System.out.println(array[i]);
        }
    }

    public static <B> void reverseArray (B[] array){

        Object[] copyArray = new Object[array.length];

        for (int i = array.length-1; i >= 0; i--){
            int distance = array.length-1;
            copyArray[distance-i] = array[i];
        }


        for (int i = 0; i < array.length; i++){
            array[i] = (B) copyArray[i]; //Casting
        }
    }


    public static void main(String[] args) {
        Integer[] intArray = {2,3,6,7};
        Double[] doubleArray = {1.3, 2.5, 3.2, 4.1};

        printArray(intArray);
        reverseArray(intArray);
        printArray(intArray);

    }
}
