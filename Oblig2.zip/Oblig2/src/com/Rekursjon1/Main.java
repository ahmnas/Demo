package com.Rekursjon1;

/* Oppgave 1.1
Konverter følgende metode til en løsning med rekurosjon:

static int sum(int x) {
    int sum = 0;
    for(int i = x; i > 0; i--) {
        sum = sum + i;
    }

    return sum;
}
 */

public class Main {
    static int sum(int x) {
        if (x > 0) {
            return x + sum(x - 1);
        }
        return 0;
    }

    /* Oppgave 1.2*/
  static int pow(int base, int exponent) {

        if (exponent < 1 ){
            return 1 ;
        }
        else return base* pow(base , exponent-=1) ;
    }

    /* Oppgave 1.3
    En metode som skriver ut verdiene i en tabell (int[]array) baklengs
    Kilde: https://stackoverflow.com/questions/35369011/reverse-an-array-in-java-using-recursion*/

    static void baklengsTabell(int[] array, int position){
        if(position >= 0){
            System.out.println(array[position]);
            baklengsTabell(array, position -1);

        }

    }

    /* Oppgave 1.4
    En metode som finner den minste veriden i en heltallstabell(int[]array)
    */

    static void minRek(int[]array, int minV, int position){

        if(position+1 >= array.length){
            System.out.println(minV);
            return;
        }

        int nesteVerdi = array[position+1];
        int min = minV;

        if(nesteVerdi < minV){
            min = nesteVerdi;
        }

        minRek(array, min, position+1);

    }

    /* Oppgave 1.5  */

    static int findNumber(int[]array, int number, int position){
        if (position >= array.length)
            return -1;

        if(array[position] == number){
            return position;
        }

        return findNumber(array,number,position+1);

    }

    public static void main(String[] args) {

        //System.out.print(sum(5));
        //System.out.println(pow(5, 2));

        int[] array ={2,3,5,8,9};

        //baklengsTabell(array, array.length -1);
        //minRek(array,array[0],0);

        int foundNumber = findNumber(array, 7 , 0);
        System.out.println(foundNumber);


    }
}



