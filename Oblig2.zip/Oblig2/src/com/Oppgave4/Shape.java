package com.Oppgave4;

public abstract class Shape {
    public abstract void draw() ;
    // Deraw metoden må være abstract fordi alle Shape-klassene som arver fra Shape klassen må
    // ha denne metoden
}

class Circle extends Shape{

    @Override
    public void draw() {
        System.out.println("This is a circle");
    }
}

class Rectangle extends Shape{

    @Override
    public void draw() {
        System.out.println("This is a rectangle");
    }
}
